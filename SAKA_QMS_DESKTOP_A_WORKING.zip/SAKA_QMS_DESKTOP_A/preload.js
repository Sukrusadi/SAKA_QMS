const { contextBridge, ipcRenderer } = require('electron');

// Load libraries in the privileged preload context (works with contextIsolation=true)
// so renderer.js does NOT need require().
const pdfLib = require('pdf-lib');
const pdfjsLib = require('pdfjs-dist/legacy/build/pdf.js');
pdfjsLib.GlobalWorkerOptions.workerSrc = require('pdfjs-dist/legacy/build/pdf.worker.js');

contextBridge.exposeInMainWorld('qmsAPI', {
  pickPdf: () => ipcRenderer.invoke('pick-pdf'),
  savePdf: (payload) => ipcRenderer.invoke('save-pdf', payload),
  saveJson: (payload) => ipcRenderer.invoke('save-json', payload),
});

// Expose only what we need.
contextBridge.exposeInMainWorld('qmsLib', {
  pdfLib: {
    PDFDocument: pdfLib.PDFDocument,
    rgb: pdfLib.rgb,
    StandardFonts: pdfLib.StandardFonts,
  },
  pdfjsLib,
});
