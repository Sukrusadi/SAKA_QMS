/* global qmsAPI, qmsLib */
// Libraries are provided by preload.js to keep contextIsolation=true
const { PDFDocument, rgb, StandardFonts } = window.qmsLib.pdfLib;
const pdfjsLib = window.qmsLib.pdfjsLib;

const els = {
  btnOpen: document.getElementById('btnOpen'),
  btnAuto: document.getElementById('btnAuto'),
  btnExportPdf: document.getElementById('btnExportPdf'),
  btnExportJson: document.getElementById('btnExportJson'),
  status: document.getElementById('status'),
  canvas: document.getElementById('pdfCanvas'),
  overlay: document.getElementById('overlay'),
  viewer: document.getElementById('viewer'),
  fieldList: document.getElementById('fieldList'),
};

let state = {
  pdfBytes: null,
  pdfPath: null,
  pdfDoc: null,
  page: null,
  viewport: null,
  extractedText: '',
  __textItems: [],
  fields: [],
};

function setStatus(msg){ els.status.textContent = msg; }
function esc(s){
  return (s ?? '').toString()
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
}
function slugifyTR(s){
  return (s||'').toString().trim().toLowerCase()
    .replace(/[ğ]/g,'g').replace(/[ü]/g,'u').replace(/[ş]/g,'s').replace(/[ı]/g,'i').replace(/[ö]/g,'o').replace(/[ç]/g,'c')
    .replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,50);
}

async function renderFirstPage(){
  const doc = await pdfjsLib.getDocument({ data: state.pdfBytes }).promise;
  state.pdfDoc = doc;
  const page = await doc.getPage(1);
  state.page = page;

  const baseViewport = page.getViewport({ scale: 1 });
  const desiredWidth = els.viewer.clientWidth - 30;
  const scale = desiredWidth / baseViewport.width;
  const viewport = page.getViewport({ scale });
  state.viewport = viewport;

  const canvas = els.canvas;
  const ctx = canvas.getContext('2d', { alpha: false });
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);

  els.overlay.style.width = canvas.width + 'px';
  els.overlay.style.height = canvas.height + 'px';
  els.overlay.style.left = ((els.viewer.clientWidth - canvas.width) / 2) + 'px';
  els.overlay.style.top = '0px';

  await page.render({ canvasContext: ctx, viewport }).promise;

  const tc = await page.getTextContent();
  const items = tc.items.map(it => {
    const tx = pdfjsLib.Util.transform(viewport.transform, it.transform);
    const x = tx[4], y = tx[5];
    const fontHeight = Math.hypot(tx[2], tx[3]);
    return { str: it.str || '', x, y, fontHeight };
  });
  state.__textItems = items;
  state.extractedText = items.map(i => i.str).join(' ');

  setStatus('PDF yüklendi. Otomatik alan çıkarabilirsin.');
  els.btnAuto.disabled = false;
}

function guessFieldsFromText(text){
  const t = (text||'').toLowerCase();
  const dict = [
    {label:'Müşteri Adı', key:'musteri_adi', type:'text', required:true, pats:[/müşteri/,/customer/]},
    {label:'Sipariş Emri No (P.O.)', key:'siparis_emri_no', type:'text', required:true, pats:[/sipariş/,/\bpo\b/,/purchase\s*order/]},
    {label:'İş Emri No', key:'is_emri_no', type:'text', required:true, pats:[/iş\s*emri/,/work\s*order/]},
    {label:'Parça No', key:'parca_no', type:'text', required:true, pats:[/parça\s*no/,/part\s*no/]},
    {label:'Parça Tanımı', key:'parca_tanimi', type:'text', required:false, pats:[/parça\s*tanım/,/description/]},
    {label:'Teknik Resim Rev.', key:'teknik_resim_rev', type:'text', required:false, pats:[/teknik\s*resim/,/drawing/]},
    {label:'Malzeme Cinsi', key:'malzeme_cinsi', type:'text', required:false, pats:[/malzeme\s*cinsi/,/material\s*type/]},
    {label:'Malzeme Ölçüsü', key:'malzeme_olcusu', type:'text', required:false, pats:[/malzeme\s*ölçü/,/material\s*size/]},
    {label:'Sipariş Miktarı', key:'siparis_miktari', type:'number', required:true, pats:[/sipariş\s*miktar/,/order\s*qty/,/quantity/]},
    {label:'İstenen Teslimat Tarihi', key:'istenen_teslimat', type:'date', required:false, pats:[/teslimat\s*tarihi/,/delivery\s*date/]},
    {label:'İş Emri Açılış Tarihi', key:'acilis_tarihi', type:'date', required:true, pats:[/açılış\s*tarihi/,/issue\s*date/,/\btarih\b/,/date/]},
    {label:'GKK Rapor No', key:'gkk_rapor_no', type:'text', required:false, pats:[/gkk/,/inspection\s*report/]},
    {label:'FAI Kodu', key:'fai_kodu', type:'text', required:false, pats:[/\bfai\b/,/first\s*article/]},
    {label:'Not / Kritik Noktalar', key:'kritik_noktalar', type:'textarea', required:false, pats:[/kritik/,/not/,/remarks/]},
  ];

  const found = [];
  for (const d of dict){
    if (d.pats.some(rx => rx.test(t))){
      found.push({ ...d, key: slugifyTR(d.key) });
    }
  }
  const must = [
    {label:'Müşteri Adı', key:'musteri_adi', type:'text', required:true},
    {label:'İş Emri No', key:'is_emri_no', type:'text', required:true},
    {label:'Parça No', key:'parca_no', type:'text', required:true},
    {label:'İş Emri Açılış Tarihi', key:'acilis_tarihi', type:'date', required:true},
  ].map(x=>({ ...x, key: slugifyTR(x.key) }));
  for (const m of must){
    if (!found.some(f=>f.key===m.key)) found.unshift(m);
  }
  const uniq=[];
  for (const f of found){ if(!uniq.some(u=>u.key===f.key)) uniq.push(f); }
  return uniq;
}

function autoPlaceFields(fields){
  const items = state.__textItems || [];
  const placed = [];

  function findItemByRegex(rx){
    const cand = items.filter(it => rx.test((it.str||'').toLowerCase()));
    cand.sort((a,b)=> b.fontHeight - a.fontHeight);
    return cand[0] || null;
  }

  const map = [
    { key:'musteri_adi', rx:/müşteri|customer/ },
    { key:'siparis_emri_no', rx:/sipariş|purchase\s*order|\bpo\b/ },
    { key:'is_emri_no', rx:/iş\s*emri|work\s*order/ },
    { key:'parca_no', rx:/parça\s*no|part\s*no/ },
    { key:'parca_tanimi', rx:/parça\s*tanım|description/ },
    { key:'acilis_tarihi', rx:/açılış\s*tarihi|issue\s*date|\btarih\b|date/ },
    { key:'siparis_miktari', rx:/sipariş\s*miktar|qty|quantity/ },
  ];

  const byKey = Object.fromEntries(fields.map(f=>[f.key, f]));
  for (const m of map){
    const f = byKey[m.key];
    if(!f) continue;
    const it = findItemByRegex(m.rx);
    if(!it) continue;

    const w = Math.min(320, (state.viewport.width - it.x - 40));
    const h = f.type === 'textarea' ? 54 : 26;
    const x = Math.min(state.viewport.width - w - 10, it.x + 160);
    const y = Math.max(10, it.y - h - 6);

    placed.push({ ...f, x, y, w, h, value:'' });
  }

  let fx = state.viewport.width - 360;
  let fy = 30;
  for (const f of fields){
    if(placed.some(p=>p.key===f.key)) continue;
    const w = 340;
    const h = f.type==='textarea' ? 54 : 26;
    placed.push({ ...f, x: fx, y: fy, w, h, value:'' });
    fy += h + 10;
  }

  return placed;
}

function drawOverlay(){
  els.overlay.innerHTML = '';
  const offsetLeft = parseFloat(els.overlay.style.left || '0');
  for (const f of state.fields){
    const div = document.createElement('div');
    div.className = 'field';
    div.style.left = (offsetLeft + f.x) + 'px';
    div.style.top = (f.y) + 'px';
    div.style.width = f.w + 'px';
    div.style.height = f.h + 'px';

    let input;
    if (f.type === 'textarea'){
      input = document.createElement('textarea');
      input.rows = 2;
    } else if (f.type === 'date'){
      input = document.createElement('input');
      input.type = 'date';
    } else if (f.type === 'number'){
      input = document.createElement('input');
      input.type = 'number';
    } else {
      input = document.createElement('input');
      input.type = 'text';
    }
    input.value = f.value || '';
    input.addEventListener('input', () => {
      f.value = input.value;
      renderFieldList();
      els.btnExportPdf.disabled = false;
      els.btnExportJson.disabled = false;
    });

    div.appendChild(input);
    els.overlay.appendChild(div);
  }
}

function renderFieldList(){
  els.fieldList.innerHTML = '';
  state.fields.forEach((f, idx)=>{
    const box = document.createElement('div');
    box.className = 'item';
    box.innerHTML = `<b>${esc(f.label)}</b> ${f.required ? '<span class="pill">Zorunlu</span>' : ''}<div class="mini">key: ${esc(f.key)} • type: ${esc(f.type)} • #${idx+1}</div><div class="mini">değer: ${esc(f.value || '')}</div>`;
    els.fieldList.appendChild(box);
  });
}

async function exportFilledPdf(){
  if(!state.pdfBytes) return;
  const pdfDoc = await PDFDocument.load(state.pdfBytes);
  const page = pdfDoc.getPages()[0];
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

  const scale = state.viewport.scale;
  const pageHeight = page.getSize().height;

  for (const f of state.fields){
    const val = (f.value || '').toString();
    if(!val) continue;

    const pdfX = f.x / scale;
    const pdfY = pageHeight - ((f.y + f.h) / scale);

    const fontSize = 10;
    const padX = 2, padY = 4;
    const maxWidth = (f.w / scale) - 4;

    page.drawText(val, {
      x: pdfX + padX,
      y: pdfY + padY,
      size: fontSize,
      font,
      color: rgb(0,0,0),
      maxWidth
    });
  }

  const out = await pdfDoc.save();
  const savedPath = await qmsAPI.savePdf({ suggestedName: 'SAKA_QMS_dolu.pdf', data: out.buffer });
  if(savedPath) setStatus('Dolu PDF kaydedildi: ' + savedPath);
}

async function exportJson(){
  const record = {
    sourcePdf: state.pdfPath,
    fields: state.fields.map(f=>({ key:f.key, label:f.label, type:f.type, required:!!f.required, value:f.value||'' })),
    createdAt: new Date().toISOString()
  };
  const txt = JSON.stringify(record, null, 2);
  const savedPath = await qmsAPI.saveJson({ suggestedName: 'SAKA_QMS_kayit.json', data: txt });
  if(savedPath) setStatus('Kayıt JSON kaydedildi: ' + savedPath);
}

els.btnOpen.addEventListener('click', async ()=>{
  const res = await qmsAPI.pickPdf();
  if(!res) return;
  state.pdfBytes = res.data;
  state.pdfPath = res.filePath;
  state.fields = [];
  els.btnExportPdf.disabled = true;
  els.btnExportJson.disabled = true;
  els.fieldList.innerHTML = '';
  els.overlay.innerHTML = '';
  setStatus('PDF yükleniyor...');
  await renderFirstPage();
});

els.btnAuto.addEventListener('click', async ()=>{
  if(!state.pdfBytes) return;
  setStatus('PDF analiz ediliyor (otomatik alan çıkarım)...');
  const fields = guessFieldsFromText(state.extractedText || '');
  state.fields = autoPlaceFields(fields);
  drawOverlay();
  renderFieldList();
  setStatus('Alanlar çıkarıldı. PDF üzerinde doldurabilirsin.');
  els.btnExportPdf.disabled = false;
  els.btnExportJson.disabled = false;
});

els.btnExportPdf.addEventListener('click', exportFilledPdf);
els.btnExportJson.addEventListener('click', exportJson);

window.addEventListener('resize', async ()=>{
  if(!state.page) return;
  await renderFirstPage();
  if(state.fields?.length){
    const fields = guessFieldsFromText(state.extractedText || '');
    state.fields = autoPlaceFields(fields);
    drawOverlay();
    renderFieldList();
  }
});
