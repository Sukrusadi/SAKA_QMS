# SAKA QMS — PDF Üstüne Otomatik Alan (Seçenek A)

Bu proje, PDF formu yükleyip **otomatik alan çıkaran** ve **PDF üzerinde doldurmanı sağlayan** offline masaüstü uygulamasıdır.

## Kurulum
Node.js (LTS) kurulu olmalı.

```bash
cd SAKA_QMS_DESKTOP_A
npm install
npm start
```

## Build (EXE / APP)
Build işlemi ilgili işletim sisteminde alınır:

- Windows -> EXE
- macOS -> APP

```bash
npm run dist
```

Çıktılar `dist/` klasörüne düşer.

## Not
Bu sürüm PDF'e form alanı (AcroForm) eklemek yerine, girilen değerleri PDF üzerine yazı olarak basar ve “dolu PDF” üretir.
Denetimde genelde yeterlidir.
