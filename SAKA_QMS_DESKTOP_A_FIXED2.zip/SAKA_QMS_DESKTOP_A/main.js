const { app, BrowserWindow, dialog, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

function createWindow () {
  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    backgroundColor: '#0b0d11',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile('index.html');
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});

// Pick a PDF
ipcMain.handle('pick-pdf', async () => {
  const res = await dialog.showOpenDialog({
    properties: ['openFile'],
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (res.canceled || !res.filePaths?.length) return null;
  const filePath = res.filePaths[0];
  const buf = fs.readFileSync(filePath);
  return { filePath, data: buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };
});

// Save filled PDF
ipcMain.handle('save-pdf', async (evt, { suggestedName, data }) => {
  const res = await dialog.showSaveDialog({
    defaultPath: suggestedName || 'filled.pdf',
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (res.canceled || !res.filePath) return null;
  fs.writeFileSync(res.filePath, Buffer.from(data));
  return res.filePath;
});

// Save JSON
ipcMain.handle('save-json', async (evt, { suggestedName, data }) => {
  const res = await dialog.showSaveDialog({
    defaultPath: suggestedName || 'record.json',
    filters: [{ name: 'JSON', extensions: ['json'] }]
  });
  if (res.canceled || !res.filePath) return null;
  fs.writeFileSync(res.filePath, Buffer.from(data, 'utf-8'));
  return res.filePath;
});
