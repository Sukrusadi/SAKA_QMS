const { contextBridge, ipcRenderer } = require('electron');

// Load libraries in the privileged preload context (works with contextIsolation=true)
// so renderer.js does NOT need require().
const pdfLib = require('pdf-lib');

// pdfjs-dist has breaking changes across major versions.
// We pin it in package.json and still guard here so the app can at least open file dialogs
// even if PDF rendering fails for any reason.
let pdfjsLib = null;
try {
  pdfjsLib = require('pdfjs-dist/legacy/build/pdf.js');
  // workerSrc must be a string path/URL. The legacy worker resolves to a file path.
  // eslint-disable-next-line global-require
  const workerPath = require.resolve('pdfjs-dist/legacy/build/pdf.worker.js');
  pdfjsLib.GlobalWorkerOptions.workerSrc = workerPath;
} catch (e) {
  // leave pdfjsLib as null; renderer will show a friendly error.
  // eslint-disable-next-line no-console
  console.error('PDFJS load failed:', e);
}

contextBridge.exposeInMainWorld('qmsAPI', {
  pickPdf: () => ipcRenderer.invoke('pick-pdf'),
  savePdf: (payload) => ipcRenderer.invoke('save-pdf', payload),
  saveJson: (payload) => ipcRenderer.invoke('save-json', payload),
});

// Expose only what we need.
contextBridge.exposeInMainWorld('qmsLib', {
  pdfLib: {
    PDFDocument: pdfLib.PDFDocument,
    rgb: pdfLib.rgb,
    StandardFonts: pdfLib.StandardFonts,
  },
  pdfjsLib,
});
